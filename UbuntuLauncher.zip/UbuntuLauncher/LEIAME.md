# Ubuntu Launcher (protótipo) – Moto G56

## Gerar o APK
1. Instale o Android Studio (Ladybug ou mais novo) e abra a pasta UbuntuLauncher.
2. Aguarde o Gradle sincronizar (precisa de internet só nessa hora).
3. Menu Build > Build APK(s). O arquivo fica em app/build/outputs/apk/debug/app-debug.apk
4. Passe o APK para o celular, abra e permita "instalar apps desconhecidos".

## Definir como launcher
Configurações > Apps > Apps padrão > App de início > Ubuntu Launcher
(ou aperte o botão Home e escolha "Ubuntu Launcher" > Sempre).

## Fonte Ubuntu (opcional)
Veja o comentário em ui/Theme.kt.
