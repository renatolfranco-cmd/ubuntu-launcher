package com.renato.ubuntulauncher.data

import android.content.Context

/** Guarda as configurações do launcher (tudo local, offline). */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    var accent: Int
        get() = sp.getInt("accent", 0xFFE95420.toInt())
        set(v) { sp.edit().putInt("accent", v).apply() }
    var light: Boolean
        get() = sp.getBoolean("light", false)
        set(v) { sp.edit().putBoolean("light", v).apply() }
    var dockBottom: Boolean
        get() = sp.getBoolean("dockBottom", false)
        set(v) { sp.edit().putBoolean("dockBottom", v).apply() }
    var iconSize: Int
        get() = sp.getInt("iconSize", 52)
        set(v) { sp.edit().putInt("iconSize", v).apply() }
    var columns: Int
        get() = sp.getInt("columns", 4)
        set(v) { sp.edit().putInt("columns", v).apply() }
    var wallpaper: Int
        get() = sp.getInt("wallpaper", 0)
        set(v) { sp.edit().putInt("wallpaper", v).apply() }
    var dim: Float
        get() = sp.getFloat("dim", 0.55f)
        set(v) { sp.edit().putFloat("dim", v).apply() }
    var dock: List<String>
        get() = sp.getString("dock", "")!!.split(",").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("dock", v.joinToString(",")).apply() }
    var hidden: Set<String>
        get() = sp.getString("hidden", "")!!.split(",").filter { it.isNotBlank() }.toSet()
        set(v) { sp.edit().putString("hidden", v.joinToString(",")).apply() }

    fun uses(pkg: String): Int = sp.getInt("use_$pkg", 0)
    fun bump(pkg: String) { sp.edit().putInt("use_$pkg", uses(pkg) + 1).apply() }

    /** Backup do layout em texto simples (chave=valor). */
    fun export(): String = listOf(
        "accent=$accent", "light=$light", "dockBottom=$dockBottom", "iconSize=$iconSize",
        "columns=$columns", "wallpaper=$wallpaper", "dim=$dim",
        "dock=${dock.joinToString(",")}", "hidden=${hidden.joinToString(",")}"
    ).joinToString("\n")

    fun import(text: String) {
        text.lines().forEach { line ->
            val k = line.substringBefore("=", "")
            val v = line.substringAfter("=", "")
            when (k) {
                "accent" -> v.toIntOrNull()?.let { accent = it }
                "light" -> light = v.toBoolean()
                "dockBottom" -> dockBottom = v.toBoolean()
                "iconSize" -> v.toIntOrNull()?.let { iconSize = it }
                "columns" -> v.toIntOrNull()?.let { columns = it }
                "wallpaper" -> v.toIntOrNull()?.let { wallpaper = it }
                "dim" -> v.toFloatOrNull()?.let { dim = it }
                "dock" -> dock = v.split(",").filter { it.isNotBlank() }
                "hidden" -> hidden = v.split(",").filter { it.isNotBlank() }.toSet()
            }
        }
    }
}
