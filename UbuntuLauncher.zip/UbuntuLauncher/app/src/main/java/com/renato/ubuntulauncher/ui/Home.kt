package com.renato.ubuntulauncher.ui

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val PT_BR: Locale = Locale.forLanguageTag("pt-BR")

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(vm: LauncherViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var drawer by remember { mutableStateOf(false) }
    var overview by remember { mutableStateOf(false) }
    var quick by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val pager = rememberPagerState(pageCount = { 3 })

    LaunchedEffect(vm.homeSignal) { drawer = false; overview = false; quick = false; settings = false; menu = false }
    BackHandler(drawer || overview || quick || settings) {
        drawer = false; overview = false; quick = false; settings = false
    }

    val now by produceState(System.currentTimeMillis()) {
        while (true) { value = System.currentTimeMillis(); delay(15_000) }
    }
    val batt by produceState(0) {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        while (true) { value = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY); delay(30_000) }
    }
    val blurRadius by animateDpAsState(if (drawer || overview) 18.dp else 0.dp, tween(250), label = "blur")
    val launch: (String) -> Unit = { pkg -> vm.launchApp(ctx, pkg) }

    Box(Modifier.fillMaxSize()) {
        // ---------- Tela inicial (desfoca quando a gaveta abre) ----------
        Box(
            Modifier.fillMaxSize()
                .then(if (blurRadius > 0.dp) Modifier.blur(blurRadius) else Modifier)
        ) {
            Wallpaper(vm.wallpaper)
            var acc by remember { mutableStateOf(0f) }
            Column(
                Modifier.fillMaxSize()
                    .pointerInput(Unit) { detectTapGestures(onLongPress = { menu = true }) }
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragStart = { acc = 0f },
                            onVerticalDrag = { _, dy -> acc += dy },
                            onDragEnd = { if (acc < -120f) drawer = true else if (acc > 120f) quick = true }
                        )
                    }
            ) {
                TopBar(now, batt) { overview = true }
                if (vm.dockBottom) {
                    Column(Modifier.weight(1f).navigationBarsPadding()) {
                        Pages(vm, pager, now, Modifier.weight(1f))
                        Dock(vm, vertical = false, onGrid = { drawer = true }, launch = launch)
                    }
                } else {
                    Row(Modifier.weight(1f).navigationBarsPadding()) {
                        Dock(vm, vertical = true, onGrid = { drawer = true }, launch = launch)
                        Pages(vm, pager, now, Modifier.weight(1f))
                    }
                }
            }
            // Menu de pressionar e segurar
            Box(Modifier.align(Alignment.Center)) {
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Papel de parede") },
                        onClick = { vm.setWallpaper((vm.wallpaper + 1) % 3); menu = false })
                    DropdownMenuItem(text = { Text("Configurações do launcher") },
                        onClick = { settings = true; menu = false })
                }
            }
        }

        // ---------- Gaveta "Mostrar aplicativos" ----------
        AnimatedVisibility(
            visible = drawer,
            enter = fadeIn(tween(250)) + scaleIn(tween(250), initialScale = 0.92f),
            exit = fadeOut(tween(200)) + scaleOut(tween(200), targetScale = 0.92f)
        ) { AppDrawer(vm) { drawer = false } }

        // ---------- Atividades (ambientes de trabalho) ----------
        AnimatedVisibility(visible = overview, enter = fadeIn(tween(250)), exit = fadeOut(tween(200))) {
            Overview(vm, pager, onPick = { page ->
                scope.launch { pager.animateScrollToPage(page) }; overview = false
            }, onApps = { overview = false; drawer = true })
        }

        // ---------- Painel rápido ----------
        AnimatedVisibility(
            visible = quick,
            enter = slideInVertically(tween(250)) { -it } + fadeIn(tween(250)),
            exit = slideOutVertically(tween(200)) { -it } + fadeOut(tween(200))
        ) { QuickPanel { quick = false } }

        // ---------- Configurações ----------
        AnimatedVisibility(visible = settings, enter = fadeIn(tween(250)), exit = fadeOut(tween(200))) {
            LauncherSettings(vm) { settings = false }
        }
    }
}

@Composable
private fun TopBar(now: Long, batt: Int, onActivities: () -> Unit) {
    val hm = remember { SimpleDateFormat("HH:mm", PT_BR) }
    val dt = remember { SimpleDateFormat("EEE, d MMM", PT_BR) }
    Box(
        Modifier.fillMaxWidth().background(Color.Black.copy(alpha = 0.55f))
            .statusBarsPadding().height(36.dp).padding(horizontal = 8.dp)
    ) {
        Text(
            "Atividades",
            Modifier.align(Alignment.CenterStart).clip(RoundedCornerShape(14.dp))
                .clickable(onClick = onActivities).padding(horizontal = 10.dp, vertical = 4.dp),
            color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium
        )
        Text("${dt.format(Date(now))}  ${hm.format(Date(now))}", Modifier.align(Alignment.Center),
            color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text("📶 🔊 🔋$batt%", Modifier.align(Alignment.CenterEnd), color = Color.White, fontSize = 12.sp)
    }
}

@Composable
private fun Pages(vm: LauncherViewModel, pager: PagerState, now: Long, modifier: Modifier) {
    val hm = remember { SimpleDateFormat("HH:mm", PT_BR) }
    val dt = remember { SimpleDateFormat("EEEE, d 'de' MMMM", PT_BR) }
    Box(modifier) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (page == 0) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(hm.format(Date(now)), color = Color.White, fontSize = 76.sp, fontWeight = FontWeight.Light)
                        Text(dt.format(Date(now)).replaceFirstChar { it.uppercase() },
                            color = Color.White.copy(alpha = 0.85f), fontSize = 18.sp)
                    }
                } else {
                    Text("Área de trabalho ${page + 1}", color = Color.White.copy(alpha = 0.35f), fontSize = 16.sp)
                }
            }
        }
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(3) { i ->
                Box(Modifier.size(if (pager.currentPage == i) 9.dp else 6.dp)
                    .background(if (pager.currentPage == i) Color(vm.accent) else Color.White.copy(alpha = 0.4f), CircleShape))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Dock(vm: LauncherViewModel, vertical: Boolean, onGrid: () -> Unit, launch: (String) -> Unit) {
    val content: @Composable () -> Unit = {
        vm.dockApps.forEach { app ->
            Box(
                Modifier.size((vm.iconSize + 10).dp)
                    .combinedClickable(onClick = { launch(app.pkg) }, onLongClick = { vm.toggleDock(app.pkg) }),
                contentAlignment = Alignment.Center
            ) {
                Image(app.icon, app.label, Modifier.size(vm.iconSize.dp).clip(RoundedCornerShape(14.dp)))
                if (app.pkg in vm.opened) {
                    Box(Modifier.align(if (vertical) Alignment.CenterStart else Alignment.BottomCenter)
                        .size(5.dp).background(Color(vm.accent), CircleShape))
                }
            }
        }
        // Botão "Mostrar aplicativos" (grade de 9 pontos)
        Box(Modifier.size((vm.iconSize + 10).dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onGrid),
            contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(28.dp)) {
                val gap = size.width / 3
                for (r in 0..2) for (c in 0..2) {
                    drawCircle(Color.White, 3.5.dp.toPx(), Offset(gap * (c + 0.5f), gap * (r + 0.5f)))
                }
            }
        }
    }
    if (vertical) {
        Column(
            Modifier.fillMaxHeight().width((vm.iconSize + 22).dp).background(Color.Black.copy(alpha = 0.35f))
                .padding(vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) { content() }
    } else {
        Row(
            Modifier.fillMaxWidth().background(Color.Black.copy(alpha = 0.35f)).padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) { content() }
    }
}

@Composable
private fun Overview(vm: LauncherViewModel, pager: PagerState, onPick: (Int) -> Unit, onApps: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.75f)).clickable(
        indication = null, interactionSource = remember { MutableInteractionSource() }) { onApps() }) {
        Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Áreas de trabalho", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                repeat(3) { i ->
                    Box(
                        Modifier.weight(1f).aspectRatio(0.5f).clip(RoundedCornerShape(14.dp))
                            .then(if (pager.currentPage == i) Modifier.background(Color(vm.accent).copy(alpha = 0.9f)).padding(3.dp) else Modifier)
                            .clip(RoundedCornerShape(12.dp)).clickable { onPick(i) }
                    ) {
                        Wallpaper(vm.wallpaper)
                        Text("${i + 1}", Modifier.align(Alignment.Center), color = Color.White, fontSize = 28.sp)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Text("Toque num ambiente para abrir · toque fora para ver os aplicativos",
                color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
        }
    }
}

@Composable
private fun QuickPanel(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var torch by remember { mutableStateOf(false) }
    fun open(action: String) { try { ctx.startActivity(Intent(action)) } catch (_: Exception) {}; onClose() }
    fun toggleTorch() {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torch = !torch
            cm.setTorchMode(id, torch)
        } catch (_: Exception) {}
    }
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)).clickable(
        indication = null, interactionSource = remember { MutableInteractionSource() }) { onClose() }) {
        Column(
            Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(12.dp)
                .background(Color(0xFF2C2C2C), RoundedCornerShape(24.dp)).padding(16.dp)
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {},
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Tile("Wi-Fi", false, Modifier.weight(1f)) { open(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) }
                Tile("Bluetooth", false, Modifier.weight(1f)) { open(Settings.ACTION_BLUETOOTH_SETTINGS) }
                Tile("Volume", false, Modifier.weight(1f)) { open(Settings.Panel.ACTION_VOLUME) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Tile("Brilho", false, Modifier.weight(1f)) { open(Settings.ACTION_DISPLAY_SETTINGS) }
                Tile("Modo avião", false, Modifier.weight(1f)) { open(Settings.ACTION_AIRPLANE_MODE_SETTINGS) }
                Tile("Lanterna", torch, Modifier.weight(1f)) { toggleTorch() }
            }
        }
    }
}

@Composable
private fun Tile(label: String, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(64.dp).clip(RoundedCornerShape(18.dp))
            .background(if (active) UbuntuOrange else Color.White.copy(alpha = 0.12f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
}
