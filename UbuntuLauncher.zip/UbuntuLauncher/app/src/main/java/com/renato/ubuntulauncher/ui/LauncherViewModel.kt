package com.renato.ubuntulauncher.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.renato.ubuntulauncher.data.AppInfo
import com.renato.ubuntulauncher.data.AppRepository
import com.renato.ubuntulauncher.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LauncherViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)

    var apps by mutableStateOf<List<AppInfo>>(emptyList()); private set
    var accent by mutableStateOf(prefs.accent); private set
    var light by mutableStateOf(prefs.light); private set
    var dockBottom by mutableStateOf(prefs.dockBottom); private set
    var iconSize by mutableStateOf(prefs.iconSize); private set
    var columns by mutableStateOf(prefs.columns); private set
    var wallpaper by mutableStateOf(prefs.wallpaper); private set
    var dim by mutableStateOf(prefs.dim); private set
    var dock by mutableStateOf(prefs.dock); private set
    var hidden by mutableStateOf(prefs.hidden); private set
    var homeSignal by mutableStateOf(0)

    /** Apps abertos nesta sessão (mostra o indicador laranja no dock). */
    val opened = mutableStateListOf<String>()

    val visibleApps: List<AppInfo> get() = apps.filter { it.pkg !in hidden }
    val dockApps: List<AppInfo> get() = dock.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }

    fun refresh() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { AppRepository.load(getApplication()) }
            apps = list
            if (dock.isEmpty()) {
                val preferred = listOf(
                    "com.google.android.dialer", "com.google.android.apps.messaging",
                    "com.android.chrome", "com.motorola.camera3", "com.android.settings"
                )
                val picks = preferred.filter { p -> list.any { it.pkg == p } }
                    .ifEmpty { list.take(5).map { it.pkg } }.take(5)
                setDock(picks)
            }
        }
    }

    fun reloadPrefs() {
        accent = prefs.accent; light = prefs.light; dockBottom = prefs.dockBottom
        iconSize = prefs.iconSize; columns = prefs.columns; wallpaper = prefs.wallpaper
        dim = prefs.dim; dock = prefs.dock; hidden = prefs.hidden
    }

    fun launchApp(ctx: Context, pkg: String) {
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let {
            ctx.startActivity(it)
            prefs.bump(pkg)
            if (pkg !in opened) opened.add(pkg)
        }
    }
    fun appInfo(ctx: Context, pkg: String) = ctx.startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
    )
    fun uninstall(ctx: Context, pkg: String) = ctx.startActivity(
        Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
    )

    private fun setDock(v: List<String>) { dock = v; prefs.dock = v }
    fun toggleDock(pkg: String) = setDock(if (pkg in dock) dock - pkg else dock + pkg)
    fun hide(pkg: String) { hidden = hidden + pkg; prefs.hidden = hidden }
    fun unhideAll() { hidden = emptySet(); prefs.hidden = emptySet() }

    fun setAccent(v: Int) { accent = v; prefs.accent = v }
    fun setLight(v: Boolean) { light = v; prefs.light = v }
    fun setDockBottom(v: Boolean) { dockBottom = v; prefs.dockBottom = v }
    fun setIconSize(v: Int) { iconSize = v; prefs.iconSize = v }
    fun setColumns(v: Int) { columns = v; prefs.columns = v }
    fun setWallpaper(v: Int) { wallpaper = v; prefs.wallpaper = v }
    fun setDim(v: Float) { dim = v; prefs.dim = v }
}
