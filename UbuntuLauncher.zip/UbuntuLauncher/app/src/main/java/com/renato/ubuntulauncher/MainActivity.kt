package com.renato.ubuntulauncher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.renato.ubuntulauncher.ui.HomeScreen
import com.renato.ubuntulauncher.ui.LauncherViewModel
import com.renato.ubuntulauncher.ui.UbuntuTheme

class MainActivity : ComponentActivity() {
    private val vm: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            UbuntuTheme(accent = vm.accent, light = vm.light) { HomeScreen(vm) }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refresh() // atualiza a lista caso algum app tenha sido instalado/removido
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        vm.homeSignal++ // botão Home: fecha gaveta/painéis e volta à tela inicial
    }
}
