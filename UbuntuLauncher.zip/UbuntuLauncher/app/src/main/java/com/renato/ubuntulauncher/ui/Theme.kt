package com.renato.ubuntulauncher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val UbuntuOrange = Color(0xFFE95420)
val Aubergine = Color(0xFF2C001E)
val AubergineMid = Color(0xFF5E2750)
val WarmGrey = Color(0xFF77216F)
val TextMuted = Color(0xFFAEA79F)

/** Cor de destaque padrão + 9 cores Yaru. */
val YaruAccents = listOf(
    "Ubuntu" to 0xFFE95420, "Bark" to 0xFF787859, "Sage" to 0xFF657B69,
    "Olive" to 0xFF4B8501, "Viridian" to 0xFF03875B, "Prussian" to 0xFF308280,
    "Blue" to 0xFF0073E5, "Purple" to 0xFF7764D8, "Magenta" to 0xFFB34CB3, "Red" to 0xFFDA3450
)

/*
 * FONTE UBUNTU: copie Ubuntu-R.ttf para app/src/main/res/font/ubuntu_regular.ttf e troque
 * FontFamily.SansSerif por: FontFamily(Font(R.font.ubuntu_regular)) e use na Typography.
 * Sem o arquivo, o app usa a fonte sans-serif do sistema (funciona normalmente).
 */
@Composable
fun UbuntuTheme(accent: Int, light: Boolean, content: @Composable () -> Unit) {
    val a = Color(accent)
    val scheme = if (light)
        lightColorScheme(primary = a, background = Color(0xFFF7F7F7), surface = Color.White, onSurface = Color(0xFF3D3D3D))
    else
        darkColorScheme(primary = a, background = Color(0xFF1E1E1E), surface = Color(0xFF2C2C2C), onSurface = Color.White)
    MaterialTheme(colorScheme = scheme, content = content)
}

/** Papel de parede gerado em código (degradê aubergine -> laranja + formas abstratas). */
@Composable
fun Wallpaper(variant: Int, modifier: Modifier = Modifier) {
    val colors = when (variant) {
        1 -> listOf(Aubergine, WarmGrey)
        2 -> listOf(Color(0xFF1E1E1E), AubergineMid, UbuntuOrange)
        else -> listOf(Aubergine, AubergineMid, UbuntuOrange)
    }
    Canvas(modifier.fillMaxSize()) {
        drawRect(Brush.linearGradient(colors, start = Offset(0f, 0f), end = Offset(size.width, size.height)))
        drawCircle(Color.White.copy(alpha = 0.06f), size.width * 0.70f, Offset(size.width * 0.90f, size.height * 0.15f))
        drawCircle(Color.White.copy(alpha = 0.05f), size.width * 0.50f, Offset(size.width * 0.10f, size.height * 0.85f))
        drawCircle(Color.Black.copy(alpha = 0.10f), size.width * 0.35f, Offset(size.width * 0.70f, size.height * 0.70f))
    }
}
