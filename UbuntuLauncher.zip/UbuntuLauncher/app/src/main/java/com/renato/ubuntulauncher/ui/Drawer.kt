package com.renato.ubuntulauncher.ui

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val SettingsEntries = listOf(
    "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS,
    "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
    "Tela" to Settings.ACTION_DISPLAY_SETTINGS,
    "Som" to Settings.ACTION_SOUND_SETTINGS,
    "Bateria" to Intent.ACTION_POWER_USAGE_SUMMARY,
    "Aplicativos" to Settings.ACTION_APPLICATION_SETTINGS
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppDrawer(vm: LauncherViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var frequent by remember { mutableStateOf(false) }
    var menuPkg by remember { mutableStateOf<String?>(null) }
    val base = vm.visibleApps
    val list = remember(query, frequent, base) {
        when {
            query.isNotBlank() -> base.filter { it.label.contains(query, ignoreCase = true) }
            frequent -> base.filter { vm.prefs.uses(it.pkg) > 0 }.sortedByDescending { vm.prefs.uses(it.pkg) }.take(20)
            else -> base
        }
    }
    val settingsHits = if (query.isBlank()) emptyList() else SettingsEntries.filter { it.first.contains(query, ignoreCase = true) }

    Column(Modifier.fillMaxSize().background(Color.Black.copy(alpha = vm.dim)).statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        TextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Digite para pesquisar…") },
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.White.copy(alpha = 0.14f), unfocusedContainerColor = Color.White.copy(alpha = 0.14f),
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedPlaceholderColor = Color.White.copy(alpha = 0.6f), unfocusedPlaceholderColor = Color.White.copy(alpha = 0.6f),
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = Color(vm.accent)
            )
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Frequentes", frequent, vm.accent) { frequent = true }
            Chip("Todos", !frequent, vm.accent) { frequent = false }
        }
        Spacer(Modifier.height(10.dp))
        settingsHits.forEach { (name, action) ->
            Text("⚙ Configurações: $name", color = Color.White, modifier = Modifier.fillMaxWidth()
                .clickable { try { ctx.startActivity(Intent(action)) } catch (_: Exception) {}; onClose() }.padding(vertical = 10.dp))
        }
        LazyVerticalGrid(columns = GridCells.Fixed(vm.columns), modifier = Modifier.weight(1f)) {
            items(list, key = { it.pkg }) { app ->
                Box {
                    Column(
                        Modifier.fillMaxWidth().padding(vertical = 8.dp)
                            .combinedClickable(
                                onClick = { vm.launchApp(ctx, app.pkg); onClose() },
                                onLongClick = { menuPkg = app.pkg }
                            ),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(app.icon, app.label, Modifier.size(vm.iconSize.dp).clip(RoundedCornerShape(14.dp)))
                        Spacer(Modifier.height(4.dp))
                        Text(app.label, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    DropdownMenu(expanded = menuPkg == app.pkg, onDismissRequest = { menuPkg = null }) {
                        DropdownMenuItem(text = { Text(if (app.pkg in vm.dock) "Remover do dock" else "Fixar no dock") },
                            onClick = { vm.toggleDock(app.pkg); menuPkg = null })
                        DropdownMenuItem(text = { Text("Informações do app") },
                            onClick = { vm.appInfo(ctx, app.pkg); menuPkg = null })
                        DropdownMenuItem(text = { Text("Desinstalar") },
                            onClick = { vm.uninstall(ctx, app.pkg); menuPkg = null })
                        DropdownMenuItem(text = { Text("Ocultar") },
                            onClick = { vm.hide(app.pkg); menuPkg = null })
                    }
                }
            }
        }
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, accent: Int, onClick: () -> Unit) {
    Text(label, color = Color.White, fontSize = 13.sp,
        modifier = Modifier.clip(RoundedCornerShape(16.dp))
            .background(if (selected) Color(accent) else Color.White.copy(alpha = 0.14f))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 6.dp))
}

@Composable
fun LauncherSettings(vm: LauncherViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        uri?.let { ctx.contentResolver.openOutputStream(it)?.use { o -> o.write(vm.prefs.export().toByteArray()) } }
    }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            val text = ctx.contentResolver.openInputStream(it)?.bufferedReader()?.readText().orEmpty()
            vm.prefs.import(text); vm.reloadPrefs()
        }
    }
    val txt = MaterialTheme.colorScheme.onSurface
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().padding(20.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Configurações do launcher", color = txt, fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("Fechar") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Modo claro (Yaru-light)", color = txt, modifier = Modifier.weight(1f))
            Switch(checked = vm.light, onCheckedChange = { vm.setLight(it) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Dock embaixo", color = txt, modifier = Modifier.weight(1f))
            Switch(checked = vm.dockBottom, onCheckedChange = { vm.setDockBottom(it) })
        }
        Text("Colunas da grade: ${vm.columns}", color = txt)
        Slider(value = vm.columns.toFloat(), onValueChange = { vm.setColumns(it.toInt()) }, valueRange = 3f..6f, steps = 2)
        Text("Tamanho dos ícones: ${vm.iconSize} dp", color = txt)
        Slider(value = vm.iconSize.toFloat(), onValueChange = { vm.setIconSize(it.toInt()) }, valueRange = 40f..72f)
        Text("Transparência do fundo da gaveta", color = txt)
        Slider(value = vm.dim, onValueChange = { vm.setDim(it) }, valueRange = 0.2f..0.9f)
        Text("Cor de destaque", color = txt)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(YaruAccents) { (name, c) ->
                val argb = c.toInt()
                Box(Modifier.size(40.dp).background(Color(argb), CircleShape)
                    .then(if (vm.accent == argb) Modifier.background(Color.White.copy(alpha = 0.35f), CircleShape) else Modifier)
                    .clickable { vm.setAccent(argb) }, contentAlignment = Alignment.Center) {
                    if (vm.accent == argb) Text("✓", color = Color.White)
                }
            }
        }
        Text("Papel de parede", color = txt)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(3) { i -> OutlinedButton(onClick = { vm.setWallpaper(i) }) { Text("${i + 1}") } }
        }
        Text("Backup do layout", color = txt)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { export.launch("ubuntu-launcher-backup.txt") }) { Text("Salvar backup") }
            OutlinedButton(onClick = { import.launch(arrayOf("text/plain")) }) { Text("Restaurar") }
        }
        OutlinedButton(onClick = { vm.unhideAll() }) { Text("Mostrar apps ocultos") }
    }
}
